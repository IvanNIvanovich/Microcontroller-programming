# Component constraints for C:\prog\PSoC progects\CSN_UzhNU\LabPM_1.cydsn\TopDesign\TopDesign.cysch
# Project: C:\prog\PSoC progects\CSN_UzhNU\LabPM_1.cydsn\LabPM_1.cyprj
# Date: Fri, 27 Feb 2026 07:02:56 GMT
