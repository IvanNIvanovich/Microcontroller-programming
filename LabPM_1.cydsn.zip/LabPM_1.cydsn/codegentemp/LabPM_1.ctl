-- ======================================================================
-- LabPM_1.ctl generated from LabPM_1
-- 02/27/2026 at 09:02
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
